const P="capture-popup",p="batch";export{p as B,P};

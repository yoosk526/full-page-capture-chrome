const p="capture-popup";export{p as P};

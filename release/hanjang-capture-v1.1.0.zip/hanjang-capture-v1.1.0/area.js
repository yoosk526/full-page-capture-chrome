(function(){"use strict";const a={area:{hint:"찍을 부분을 마우스로 끌어서 고르세요 · Esc를 누르면 취소",failed:"찍지 못했어요"}},d="__hanjang-area";function x(){return new Promise(t=>requestAnimationFrame(()=>requestAnimationFrame(()=>t())))}function f(){if(document.getElementById(d))return;const t=document.createElement("div");t.id=d,t.style.cssText="position:fixed;inset:0;z-index:2147483647;";const i=t.attachShadow({mode:"closed"});i.innerHTML=`
    <style>
      .layer { position: fixed; inset: 0; cursor: crosshair; background: rgba(15, 20, 30, 0.35); }
      .layer.dragging { background: transparent; }
      .box { position: fixed; display: none; border: 2px solid #fff; outline: 1px solid rgba(0,0,0,.5);
             box-shadow: 0 0 0 9999px rgba(15, 20, 30, 0.35); pointer-events: none; }
      .size { position: absolute; left: 0; top: -28px; padding: 3px 8px; border-radius: 999px;
              background: #16181d; color: #fff; font: 600 12px system-ui, sans-serif; white-space: nowrap; }
      .hint { position: fixed; left: 50%; top: 16px; transform: translateX(-50%); padding: 9px 16px;
              border-radius: 999px; background: #16181d; color: #fff; font: 500 14px system-ui, sans-serif;
              box-shadow: 0 6px 24px rgba(0,0,0,.25); pointer-events: none; }
    </style>
    <div class="layer"></div>
    <div class="box"><span class="size"></span></div>
    <div class="hint"></div>`;const s=i.querySelector(".layer"),h=i.querySelector(".box"),y=i.querySelector(".size"),c=i.querySelector(".hint");c.textContent=a.area.hint,document.documentElement.appendChild(t);let n=null,o={x:0,y:0,w:0,h:0};const l=()=>{t.remove(),window.removeEventListener("keydown",p,!0)},p=e=>{e.key==="Escape"&&(e.preventDefault(),e.stopPropagation(),l())};window.addEventListener("keydown",p,!0),s.addEventListener("pointerdown",e=>{e.preventDefault(),s.setPointerCapture(e.pointerId),n={x:e.clientX,y:e.clientY},s.classList.add("dragging"),c.style.display="none"}),s.addEventListener("pointermove",e=>{if(!n)return;const r=Math.min(n.x,e.clientX),u=Math.min(n.y,e.clientY);o={x:r,y:u,w:Math.abs(e.clientX-n.x),h:Math.abs(e.clientY-n.y)},Object.assign(h.style,{display:"block",left:`${r}px`,top:`${u}px`,width:`${o.w}px`,height:`${o.h}px`}),y.textContent=`${Math.round(o.w*devicePixelRatio)} x ${Math.round(o.h*devicePixelRatio)}`}),s.addEventListener("pointerup",async()=>{if(!n)return;n=null,l(),await x();const e={kind:"areaSelected",rect:o,viewportWidth:window.innerWidth,title:document.title,url:location.href},r=await chrome.runtime.sendMessage(e);r&&!r.ok&&m()})}function m(){const t=document.createElement("div");t.textContent=a.area.failed,t.style.cssText="position:fixed;left:50%;top:16px;transform:translateX(-50%);z-index:2147483647;padding:9px 16px;border-radius:999px;background:#d33a2c;color:#fff;font:500 14px system-ui,sans-serif",document.documentElement.appendChild(t),setTimeout(()=>t.remove(),3e3)}f()})();
